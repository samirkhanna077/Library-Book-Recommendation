package database;

import java.io.*;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Class created by Sam
 */
public class Database {

    private static final String userPath = "/Users/samirkhanna/IdeaProjects/compSciIA/src/database/Username";
    private static final String passPath = "/Users/samirkhanna/IdeaProjects/compSciIA/src/database/Password";
    private static final String teacherUsernamePath = "/Users/samirkhanna/IdeaProjects/compSciIA/src/database/TeacherUsername";
    private static final String teacherPasswordPath = "/Users/samirkhanna/IdeaProjects/compSciIA/src/database/TeacherPassword";
    private static final String namesPath = "/Users/samirkhanna/IdeaProjects/compSciIA/src/database/Names";
    private static final String booksPath = "/Users/samirkhanna/IdeaProjects/compSciIA/src/database/Books";
    private static final String authorsPath = "/Users/samirkhanna/IdeaProjects/compSciIA/src/database/Authors";
    private static final String genresPath = "/Users/samirkhanna/IdeaProjects/compSciIA/src/database/Genre";
    private static final String booksReadPath = "/Users/samirkhanna/IdeaProjects/compSciIA/src/database/BooksRead";
    private static final String genresReadPath = "/Users/samirkhanna/IdeaProjects/compSciIA/src/database/GenresRead";
    private static final String currentBookPath = "/Users/samirkhanna/IdeaProjects/compSciIA/src/database/CurrentBook";
    private static final String currentAuthorPath = "/Users/samirkhanna/IdeaProjects/compSciIA/src/database/CurrentAuthor";
    private static final String currentPagesPath = "/Users/samirkhanna/IdeaProjects/compSciIA/src/database/CurrentPages";
    private static final String currentNotesPath = "/Users/samirkhanna/IdeaProjects/compSciIA/src/database/CurrentNotes";
    private static final String futureReadsPath = "/Users/samirkhanna/IdeaProjects/compSciIA/src/database/FutureReads";
    private static final String topFiveBooksPath = "/Users/samirkhanna/IdeaProjects/compSciIA/src/database/TopFiveBooks";
    private static final String topFiveRatingsPath = "/Users/samirkhanna/IdeaProjects/compSciIA/src/database/TopFiveRatings";
    private static final String booksRatingsPath = "/Users/samirkhanna/IdeaProjects/compSciIA/src/database/BooksRatings";
    private static final String bookAdditionPath = "/Users/samirkhanna/IdeaProjects/compSciIA/src/database/BookAddition";
    private static final String bookCountsPath = "/Users/samirkhanna/IdeaProjects/compSciIA/src/database/BookCounts";
    private static final String averageRatingsPath = "/Users/samirkhanna/IdeaProjects/compSciIA/src/database/AverageRatings";
    private static final String bookHistoryPath = "/Users/samirkhanna/IdeaProjects/compSciIA/src/database/BookHistory";
    private static final String genreRecoPath = "/Users/samirkhanna/IdeaProjects/compSciIA/src/database/GenreReco";
    private static ArrayList<Double> booksRatings = new ArrayList<>();
    private static ArrayList<Double> topFiveRatings = new ArrayList<>();
    private static ArrayList<String> topFiveBooks = new ArrayList<>();
    private static ArrayList<String> currentNotes = new ArrayList<>();
    private static ArrayList<String> futureReads = new ArrayList<>();
    private static ArrayList<String> currentPages = new ArrayList<>();
    private static ArrayList<String> currentAuthor = new ArrayList<>();
    private static ArrayList<String> currentBook = new ArrayList<>();
    private static ArrayList<String> usernames = new ArrayList<>();
    private static ArrayList<String> passwords = new ArrayList<>();
    private static ArrayList<String> teacherUsername = new ArrayList<>();
    private static ArrayList<String> teacherPassword = new ArrayList<>();
    private static ArrayList<String> names = new ArrayList<>();
    private static ArrayList<String> books = new ArrayList<>();
    private static ArrayList<String> authors = new ArrayList<>();
    private static ArrayList<String> genres = new ArrayList<>();
    private static ArrayList<String> genreReco = new ArrayList<>();
    private static ArrayList<String> bookHistory = new ArrayList<>();
    private static ArrayList<Double> booksRead = new ArrayList<>();
    private static ArrayList<Double> genresRead = new ArrayList<>();
    private static ArrayList<Double> bookAddition = new ArrayList<>();
    private static ArrayList<Double> bookCounts = new ArrayList<>();
    private static ArrayList<Double> averageRatings = new ArrayList<>();

    public static ArrayList<String> getUsernames() throws FileNotFoundException {
        Scanner scanner = new Scanner(new File(userPath));
        while (scanner.hasNext()) {
            usernames.add(scanner.nextLine());
        }
        return usernames;
    }

    public static ArrayList<String> getGenreReco() throws FileNotFoundException {
        Scanner scanner = new Scanner(new File(genreRecoPath));
        while (scanner.hasNext()) {
            genreReco.add(scanner.nextLine());
        }
        return genreReco;
    }

    public static ArrayList<String> getBookHistory() throws FileNotFoundException {
        Scanner scanner = new Scanner(new File(bookHistoryPath));
        while (scanner.hasNext()) {
            bookHistory.add(scanner.nextLine());
        }
        return bookHistory;
    }

    public static ArrayList<String> getTeacherUsername() throws FileNotFoundException {
        Scanner scanner = new Scanner(new File(teacherUsernamePath));
        while (scanner.hasNext()) {
            teacherUsername.add(scanner.nextLine());
        }
        return teacherUsername;
    }

    public static ArrayList<Double> getBooksRatings() throws FileNotFoundException {
        Scanner scanner = new Scanner(new File(booksRatingsPath));
        while (scanner.hasNext()) {
            booksRatings.add(scanner.nextDouble());
        }
        return booksRatings;
    }

    public static ArrayList<Double> getAverageRatings() throws FileNotFoundException {
        Scanner scanner = new Scanner(new File(averageRatingsPath));
        while (scanner.hasNext()) {
            averageRatings.add(scanner.nextDouble());
        }
        return averageRatings;
    }

    public static ArrayList<Double> getBookAddition() throws FileNotFoundException {
        Scanner scanner = new Scanner(new File(bookAdditionPath));
        while (scanner.hasNext()) {
            bookAddition.add(scanner.nextDouble());
        }
        return bookAddition;
    }

    public static ArrayList<Double> getBookCounts() throws FileNotFoundException {
        Scanner scanner = new Scanner(new File(bookCountsPath));
        while (scanner.hasNext()) {
            bookCounts.add(scanner.nextDouble());
        }
        return bookCounts;
    }

    public static ArrayList<String> getTopFiveBooks() throws FileNotFoundException {
        Scanner scanner = new Scanner(new File(topFiveBooksPath));
        while (scanner.hasNext()) {
            topFiveBooks.add(scanner.nextLine());
        }
        return topFiveBooks;
    }

    public static ArrayList<Double> getTopFiveRatings() throws FileNotFoundException {
        Scanner scanner = new Scanner(new File(topFiveRatingsPath));
        while (scanner.hasNext()) {
            topFiveRatings.add(scanner.nextDouble());
        }
        return topFiveRatings;
    }

    public static ArrayList<String> getFutureReads() throws FileNotFoundException {
        Scanner scanner = new Scanner(new File(futureReadsPath));
        while (scanner.hasNext()) {
            futureReads.add(scanner.nextLine());
        }
        return futureReads;
    }

    public static ArrayList<String> getCurrentPages() throws FileNotFoundException {
        Scanner scanner = new Scanner(new File(currentPagesPath));
        while (scanner.hasNext()) {
            currentPages.add(scanner.nextLine());
        }
        return currentPages;
    }

    public static ArrayList<String> getCurrentNotes() throws FileNotFoundException {
        Scanner scanner = new Scanner(new File(currentNotesPath));
        while (scanner.hasNext()) {
            currentNotes.add(scanner.nextLine());
        }
        return currentPages;
    }

    public static ArrayList<String> getCurrentAuthor() throws FileNotFoundException {
        Scanner scanner = new Scanner(new File(currentAuthorPath));
        while (scanner.hasNext()) {
            currentAuthor.add(scanner.nextLine());
        }
        return currentAuthor;
    }

    public static ArrayList<String> getCurrentBook() throws FileNotFoundException {
        Scanner scanner = new Scanner(new File(currentBookPath));
        while (scanner.hasNext()) {
            currentBook.add(scanner.nextLine());
        }
        return currentBook;
    }

    public static ArrayList<String> getGenres() throws FileNotFoundException {
        Scanner scanner = new Scanner(new File(genresPath));
        while (scanner.hasNext()) {
            genres.add(scanner.nextLine());
        }
        return genres;
    }

    public static ArrayList<String> getAuthors() throws FileNotFoundException {
        Scanner scanner = new Scanner(new File(authorsPath));
        while (scanner.hasNext()) {
            authors.add(scanner.nextLine());
        }
        return authors;
    }

    public static ArrayList<String> getPasswords() throws FileNotFoundException {
        Scanner scanner = new Scanner(new File(passPath));
        while (scanner.hasNext()) {
            passwords.add(scanner.nextLine());
        }
        return passwords;
    }

    public static ArrayList<String> getTeacherPassword() throws FileNotFoundException {
        Scanner scanner = new Scanner(new File(teacherPasswordPath));
        while (scanner.hasNext()) {
            teacherPassword.add(scanner.nextLine());
        }
        return teacherPassword;
    }

    public static ArrayList<String> getNames() throws FileNotFoundException {
        Scanner scanner = new Scanner(new File(namesPath));
        while (scanner.hasNext()) {
            names.add(scanner.nextLine());
        }
        return names;
    }

    public static ArrayList<String> getBooks() throws FileNotFoundException {
        Scanner scanner = new Scanner(new File(booksPath));
        while (scanner.hasNext()) {
            books.add(scanner.nextLine());
        }
        return books;
    }

    public static ArrayList<Double> getBooksRead() throws FileNotFoundException {
        Scanner scanner = new Scanner(new File(booksReadPath));
        while (scanner.hasNext()) {
            booksRead.add(scanner.nextDouble());
        }
        return booksRead;
    }

    public static ArrayList<Double> getGenresRead() throws FileNotFoundException {
        Scanner scanner = new Scanner(new File(genresReadPath));
        while (scanner.hasNext()) {
            genresRead.add(scanner.nextDouble());
        }
        return genresRead;
    }

    public static void addUsername(String username) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(userPath, true));
        writer.append("\n").append(username);
        writer.close();
    }

    public static void addAuthors(String authors) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(authorsPath, true));
        writer.append("\n").append(authors);
        writer.close();
    }

    public static void addBookHistory(String bookHistory) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(bookHistoryPath, true));
        writer.append("\n").append(bookHistory);
        writer.close();
    }

    public static void addBooksRatings(String booksRatings) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(booksRatingsPath, true));
        writer.append("\n").append(booksRatings);
        writer.close();
    }

    public static void addPassword(String password) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(passPath, true));
        writer.append("\n").append(password);
        writer.close();
    }

    public static void addNames(String names) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(namesPath, true));
        writer.append("\n").append(names);
        writer.close();
    }

    public static void addTeacherPassword(String teacherPassword) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(teacherPasswordPath, true));
        writer.append("\n").append(teacherPassword);
        writer.close();
    }

    public static void addTeacherUsername(String teacherUsername) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(teacherUsernamePath, true));
        writer.append("\n").append(teacherUsername);
        writer.close();
    }

    public static void addBookCounts(String bookCounts) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(bookCountsPath, true));
        writer.append("\n").append(bookCounts);
        writer.close();
    }

    public static void addBookAddition(String bookAddition) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(bookAdditionPath, true));
        writer.append("\n").append(bookAddition);
        writer.close();
    }

    public static void addAverageRatings(String averageRatings) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(averageRatingsPath, true));
        writer.append("\n").append(averageRatings);
        writer.close();
    }

    public static void addBooks(String books) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(booksPath, true));
        writer.append("\n").append(books);
        writer.close();
    }

    public static void addBooksRead(String booksRead) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(booksReadPath, true));
        writer.append("\n").append(booksRead);
        writer.close();
    }

    public static void addGenresRead(String genresRead) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(genresReadPath, true));
        writer.append("\n").append(genresRead);
        writer.close();
    }

    public static void addGenres(String genres) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(genres, true));
        writer.append("\n").append(genres);
        writer.close();
    }
    public static void addTopFiveBooks(String topFiveBooks) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(topFiveBooks, true));
        writer.append("\n").append(topFiveBooks);
        writer.close();
    }
    public static void addTopFiveRatings(String topFiveRatings) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(topFiveRatings, true));
        writer.append("\n").append(topFiveRatings);
        writer.close();
    }
    public static void addCurrentBook(String currentBook) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(currentBook, true));
        writer.append("\n").append(currentBook);
        writer.close();
    }
    public static void addCurrentAuthor(String currentAuthor) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(currentAuthor, true));
        writer.append("\n").append(currentAuthor);
        writer.close();
    }
    public static void addCurrentPages(String currentPages) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(currentPages, true));
        writer.append("\n").append(currentPages);
        writer.close();
    }
    public static void addCurrentNotes(String currentNotes) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(currentNotes, true));
        writer.append("\n").append(currentNotes);
        writer.close();
    }
    public static void addFutureReads(String futureReads) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(futureReads, true));
        writer.append("\n").append(futureReads);
        writer.close();
    }

    public static String getBooksReadPath() {
        return booksReadPath;
    }
    public static String getBooksPath() {
        return booksPath;
    }
    public static String getCurrentBookPath() {
        return currentBookPath;
    }
    public static String getCurrentAuthorPath() {
        return currentAuthorPath;
    }
    public static String getFutureReadsPath() {
        return futureReadsPath;
    }
    public static String getCurrentPagesPath() {
        return currentPagesPath;
    }
    public static String getCurrentNotesPath() {
        return currentNotesPath;
    }
    public static String getBookCountsPath() {
        return bookCountsPath;
    }
    public static String getBookAdditionPath() {
        return bookAdditionPath;
    }
    public static String getAverageRatingsPath() { return averageRatingsPath; }
    public static String getTopFiveRatingsPath() {
        return topFiveRatingsPath;
    }
    public static String getTopFiveBooksPath() {
        return topFiveBooksPath;
    }
    public static String getBooksRatingsPath() {
        return booksRatingsPath;
    }
    public static String getBookHistoryPath() {
        return bookHistoryPath;
    }
    public static String getGenresReadPath() {
        return genresReadPath;
    }
    public static String getGenresPath() { return genresPath;}
    public static String getGenreRecoPath() { return genreRecoPath;}


    public static void replaceLine(String path, double bRead, int position) throws IOException {
        List<String> list = Files.readAllLines(Paths.get(path), Charset.defaultCharset());
        list.set(position,String.valueOf(bRead));
        Files.write(Paths.get(path),list,Charset.defaultCharset());
    }

    public static void replaceLineString(String path, String string, int position) throws IOException {
        List<String> list = Files.readAllLines(Paths.get(path), Charset.defaultCharset());
        list.set(position,String.valueOf(string));
        Files.write(Paths.get(path),list,Charset.defaultCharset());
    }

}
