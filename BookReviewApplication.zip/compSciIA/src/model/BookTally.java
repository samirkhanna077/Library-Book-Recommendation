package model;

import controller.AddBookController;
import controller.FinishedBookSummaryController;
import controller.LogInController;
import database.Database;
import sun.rmi.runtime.Log;

import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * Class created by Sam
 */
public class BookTally {

    public static double totalRating;
    public static double totalTally;
    public static double bookTally;
    public static double bookAverage;

    public static void incrementBookTally() throws IOException {
        try {
            bookTally = Database.getBooksRead().get(LogInController.pos);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        bookTally++;
        Database.replaceLine(Database.getBooksReadPath(), bookTally, LogInController.pos);
    }

    public static void incrementTotalRating() throws IOException {
        try {
            totalRating = Database.getBookAddition().get(FinishedBookSummaryController.currentIndex);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        totalRating = totalRating + FinishedBookSummaryController.bookRating;
        Database.replaceLine(Database.getBookAdditionPath(), totalRating, FinishedBookSummaryController.currentIndex);
    }

    public static void incrementTotalTally() throws IOException {
        try {
            totalTally = Database.getBookCounts().get(FinishedBookSummaryController.currentIndex);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        try {
            totalRating = Database.getBookAddition().get(FinishedBookSummaryController.currentIndex);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        totalRating = totalRating + FinishedBookSummaryController.bookRating;
        Database.replaceLine(Database.getBookAdditionPath(), totalRating, FinishedBookSummaryController.currentIndex);

        totalTally++;
        Database.replaceLine(Database.getBookCountsPath(), totalTally, FinishedBookSummaryController.currentIndex);
        Database.replaceLine(Database.getBookAdditionPath(), totalRating, FinishedBookSummaryController.currentIndex);
        Database.replaceLine(Database.getAverageRatingsPath(), (totalRating/totalTally), FinishedBookSummaryController.currentIndex);
    }

}
