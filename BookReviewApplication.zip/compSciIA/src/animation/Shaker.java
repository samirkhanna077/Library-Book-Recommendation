package animation;

import javafx.animation.TranslateTransition;
import javafx.scene.Node;
import javafx.util.Duration;

/**
 * Class created by Sam
 */
public class Shaker {

    private TranslateTransition transition;

    public Shaker(Node node) {
        transition = new TranslateTransition(Duration.millis(50), node);
        transition.setFromX(0f);
        transition.setByX(10f);
        transition.setCycleCount(4);
        //duration of animation
        transition.setAutoReverse(true);
        //shaker changes direction to make effect occur
    }

    public void shake() {
        transition.playFromStart();
    }

}

