package controller;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.ResourceBundle;

import database.Database;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import model.AlertBox;
import model.BookTally;
import model.SceneManager;
import sun.rmi.runtime.Log;

public class BookJournalController {
    public static int pos2;
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private AnchorPane anchorPane;

    @FXML
    private TextArea name;

    @FXML
    private Button addBookButton;

    @FXML
    private Button currentBookButton;

    @FXML
    private Label booksReadCounter;

    @FXML
    private Button bookRating;

    @FXML
    private Button futureReads;

    @FXML
    private Button logOut;

    @FXML
    private Button bookHistory;

    private String currentBook;
    private String bookTally;
    int genreVal;

    @FXML
    void initialize() throws FileNotFoundException {

        int index = 0;
        ArrayList<String> usernames = Database.getUsernames();
        //An ArrayList of usernames is created from the database containing all the usernames
        for (String user : usernames) {
        //A loop runs for every username
            if (SignUpController.user.equals(user)) {
            //If the input of the username in the sign up screen is the same as the one in the database
                pos2 = index;
                //the index position is saved
                break;
            }
            index++;
        }
        name.setText(Database.getNames().get(pos2 + 1));

        if (LogInController.pos > -1) {
            name.setText(Database.getNames().get(LogInController.pos));
        }
        try {
            //bookTally = Files.readAllLines(Paths.get(Database.getBooksReadPath()), Charset.defaultCharset()).size() > 0
             //       ? Files.readAllLines(Paths.get(Database.getBooksReadPath()), Charset.defaultCharset()).get(LogInController.pos)
             //       : "0";
            bookTally = Files.readAllLines(Paths.get(Database.getBooksReadPath()), Charset.defaultCharset()).get(LogInController.pos);
        } catch (IOException e) {
            e.printStackTrace();
        }
        double value = Double.parseDouble(bookTally);
        int val = (int) value;
        booksReadCounter.setText(String.valueOf(val));

        addBookButton.setVisible(true);
        try {
            currentBook = Files.readAllLines(Paths.get(Database.getCurrentBookPath()), Charset.defaultCharset()).get(LogInController.pos);
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (!currentBook.equals("-")) {
            addBookButton.setVisible(false);
        }

        addBookButton.setOnAction(event -> {
        //when addBookButton is clicked, an action will occur:
            try {
                new SceneManager(anchorPane).changeScene("AddBook");
                //BookJournal screen will change to AddBook screen
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        logOut.setOnAction(event -> {
            try {
                new SceneManager(anchorPane).changeScene("LogIn");
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        bookRating.setOnAction(event -> {
            try {
                new SceneManager(anchorPane).changeScene("TopBooks");
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        bookHistory.setOnAction(event -> {
            try {
                new SceneManager(anchorPane).changeScene("BookHistory");
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        futureReads.setOnAction(event -> {
            try {
                new SceneManager(anchorPane).changeScene("FutureReads");
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        currentBookButton.setOnAction(event -> {
            try {
                new SceneManager(anchorPane).changeScene("CurrentBookReview");
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

}
