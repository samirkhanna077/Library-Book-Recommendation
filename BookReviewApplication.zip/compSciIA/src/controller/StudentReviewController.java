package controller;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import animation.Shaker;
import database.Database;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import model.AlertBox;
import model.SceneManager;

public class StudentReviewController {

    private boolean found;

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private AnchorPane anchorPane;

    @FXML
    private Label addBook;

    @FXML
    private Label searchText1;

    @FXML
    private TextField studentSearch;

    @FXML
    private Button goButton;

    @FXML
    private Button backToTeach;

    @FXML
    void initialize() {
        backToTeach.setOnAction(event -> {
                    try {
                        new SceneManager(anchorPane).changeScene("TeacherJournal");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                });
        goButton.setOnAction(event -> {
            int index = 0;

            ArrayList<String> allNames = null;
            try {
                allNames = Database.getNames();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }

            for (String name : allNames) {
                if (studentSearch.getText().equals(name)) {
                    found = true;
                    break;
                }
                index++;
            }
            if (!found) {
                AlertBox.display("Error", "Student doesn't exist");
                Shaker shaker = new Shaker(studentSearch);
                shaker.shake();
               studentSearch.setText("");
                studentSearch.positionCaret(0);
            }

            else {
                try {
                    new SceneManager(anchorPane).changeScene("StudentInfo");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }
}

