package controller;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ResourceBundle;

import database.Database;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.layout.AnchorPane;
import model.SceneManager;

public class BookHistoryController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private AnchorPane anchorPane;

    @FXML
    private TextArea historyBooks;

    @FXML
    private Button backToHome;

    @FXML
    void initialize() throws IOException {

        String historyBook = Files.readAllLines(Paths.get(Database.getBookHistoryPath()), Charset.defaultCharset()).get(LogInController.pos);
        historyBooks.setText(historyBook);

        backToHome.setOnAction(event -> {
            try {
                new SceneManager(anchorPane).changeScene("BookJournal");
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }
}
