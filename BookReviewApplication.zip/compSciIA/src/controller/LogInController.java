package controller;

import animation.Shaker;
import database.Database;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import model.AlertBox;
import model.SceneManager;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

/**
 * Class created by Sam
 */
public class LogInController {

    private boolean found;
    public static int pos=-1;

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField username;

    @FXML
    private AnchorPane anchorPane;

    @FXML
    private PasswordField password;

    @FXML
    private Button logInButton;

    @FXML
    private Button signUpButton;

    @FXML
    private Button teacherLogin;

    public TextField getUsername() {
        return username;
    }

    public PasswordField getPassword() {
        return password;
    }

    public void setUsername(TextField username) {
        this.username = username;
    }

    public void setPassword(PasswordField password) {
        this.password = password;
    }

    @FXML
    void initialize() {
        logInButton.setOnAction(event -> {
            try {
                int index = 0;
                ArrayList<String> usernames = Database.getUsernames();
                ArrayList<String> passwords = Database.getPasswords();
                for (String user : usernames) {
                    if (username.getText().equals(user)) {
                        found = true;
                        pos=index;
                        break;
                    }
                    index++;
                }
                if (!found) {
                    AlertBox.display("Error", "Username doesn't exist");
                    Shaker shaker = new Shaker(username);
                    //instantiation of shaker object
                    shaker.shake();
                    username.setText("");
                    username.positionCaret(0);
                    password.setText("");
                    password.positionCaret(0);
                } else {
                    if (password.getText().equals(passwords.get(index))) {
                    //Does password equal to password saved in the database of the corresponding username?
                        new SceneManager(anchorPane).activate("BookJournal",583,437);
                        //Account will login to main page
                    } else {
                        Shaker shaker = new Shaker(password);
                        shaker.shake();
                    }
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }

        });
        signUpButton.setOnAction(event -> {
                new SceneManager(anchorPane).activate("SignUp",576,432);
        });

        teacherLogin.setOnAction(event -> {
            try {
                new SceneManager(anchorPane).changeScene("TeacherLogin");
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }
}
