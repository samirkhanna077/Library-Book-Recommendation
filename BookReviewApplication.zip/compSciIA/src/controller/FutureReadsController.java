package controller;

import java.io.IOException;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.ResourceBundle;

import database.Database;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.layout.AnchorPane;
import model.SceneManager;

public class FutureReadsController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private AnchorPane anchorPane;

    @FXML
    private TextArea readsText;

    @FXML
    private Button back;

    @FXML
    private Button set;

    String futureReads;

    @FXML
    void initialize() {
        try {
            futureReads = Files.readAllLines(Paths.get(Database.getFutureReadsPath()), Charset.defaultCharset()).get(LogInController.pos);
        } catch (IOException e) {
            e.printStackTrace();
        }

        readsText.setText(String.valueOf(futureReads));

        back.setOnAction(event -> {
            try {
                new SceneManager(anchorPane).changeScene("BookJournal");
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        set.setOnAction(event -> {
            try {
                Database.replaceLineString(Database.getFutureReadsPath(), Arrays.toString(readsText.getText().split(System.lineSeparator())), LogInController.pos);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }
}