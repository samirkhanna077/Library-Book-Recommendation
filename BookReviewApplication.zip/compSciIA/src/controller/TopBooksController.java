package controller;

import java.io.IOException;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ResourceBundle;

import database.Database;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.layout.AnchorPane;
import model.SceneManager;

public class TopBooksController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private AnchorPane anchorPane;

    @FXML
    private TextArea book1;

    @FXML
    private TextArea book2;

    @FXML
    private TextArea book3;

    @FXML
    private TextArea book4;

    @FXML
    private TextArea book5;

    @FXML
    private TextArea rating1;

    @FXML
    private TextArea rating2;

    @FXML
    private TextArea rating3;

    @FXML
    private TextArea rating4;

    @FXML
    private TextArea rating5;

    @FXML
    private Button back;

    public static int locate = -1;

    String top1;
    String top2;
    String top3;
    String top4;
    String top5;
    String top6;

    double rate1;
    double rate2;
    double rate3;
    double rate4;
    double rate5;
    double rate6;

    @FXML
    void initialize() throws IOException {
        try {
            top1 = Files.readAllLines(Paths.get(Database.getTopFiveBooksPath()), Charset.defaultCharset()).get(0);
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            top2 = Files.readAllLines(Paths.get(Database.getTopFiveBooksPath()), Charset.defaultCharset()).get(1);
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            top3 = Files.readAllLines(Paths.get(Database.getTopFiveBooksPath()), Charset.defaultCharset()).get(2);
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            top4 = Files.readAllLines(Paths.get(Database.getTopFiveBooksPath()), Charset.defaultCharset()).get(3);
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            top5 = Files.readAllLines(Paths.get(Database.getTopFiveBooksPath()), Charset.defaultCharset()).get(4);
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            rate1 = Double.parseDouble(Files.readAllLines(Paths.get(Database.getTopFiveRatingsPath()), Charset.defaultCharset()).get(0));
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            rate2 = Double.parseDouble(Files.readAllLines(Paths.get(Database.getTopFiveRatingsPath()), Charset.defaultCharset()).get(1));
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            rate3 = Double.parseDouble(Files.readAllLines(Paths.get(Database.getTopFiveRatingsPath()), Charset.defaultCharset()).get(2));
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            rate4 = Double.parseDouble(Files.readAllLines(Paths.get(Database.getTopFiveRatingsPath()), Charset.defaultCharset()).get(3));
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            rate5 = Double.parseDouble(Files.readAllLines(Paths.get(Database.getTopFiveRatingsPath()), Charset.defaultCharset()).get(4));
        } catch (IOException e) {
            e.printStackTrace();
        }

        if(locate!=-1){
            top6 = Files.readAllLines(Paths.get(Database.getBooksPath()), Charset.defaultCharset()).get(locate);
            rate6 = Double.parseDouble(Files.readAllLines(Paths.get(Database.getAverageRatingsPath()), Charset.defaultCharset()).get(locate));
            if (rate6>rate1){
                Database.replaceLineString(Database.getTopFiveRatingsPath(), String.valueOf(rate6), 0);
                Database.replaceLineString(Database.getTopFiveBooksPath(), String.valueOf(top6), 0);

                Database.replaceLineString(Database.getTopFiveRatingsPath(), String.valueOf(rate1), 1);
                Database.replaceLineString(Database.getTopFiveBooksPath(), String.valueOf(top1), 1);

                Database.replaceLineString(Database.getTopFiveRatingsPath(), String.valueOf(rate2), 2);
                Database.replaceLineString(Database.getTopFiveBooksPath(), String.valueOf(top2), 2);

                Database.replaceLineString(Database.getTopFiveRatingsPath(), String.valueOf(rate3), 3);
                Database.replaceLineString(Database.getTopFiveBooksPath(), String.valueOf(top3), 3);

                Database.replaceLineString(Database.getTopFiveRatingsPath(), String.valueOf(rate4), 4);
                Database.replaceLineString(Database.getTopFiveBooksPath(), String.valueOf(top4), 4);

            }
            else if (rate6>rate2){
                Database.replaceLineString(Database.getTopFiveRatingsPath(), String.valueOf(rate6), 1);
                Database.replaceLineString(Database.getTopFiveBooksPath(), String.valueOf(top6), 1);

                Database.replaceLineString(Database.getTopFiveRatingsPath(), String.valueOf(rate2), 2);
                Database.replaceLineString(Database.getTopFiveBooksPath(), String.valueOf(top2), 2);

                Database.replaceLineString(Database.getTopFiveRatingsPath(), String.valueOf(rate3), 3);
                Database.replaceLineString(Database.getTopFiveBooksPath(), String.valueOf(top3), 3);

                Database.replaceLineString(Database.getTopFiveRatingsPath(), String.valueOf(rate4), 4);
                Database.replaceLineString(Database.getTopFiveBooksPath(), String.valueOf(top4), 4);

            }
            else if(rate6>rate3){
                Database.replaceLineString(Database.getTopFiveRatingsPath(), String.valueOf(rate6), 2);
                Database.replaceLineString(Database.getTopFiveBooksPath(), String.valueOf(top6), 2);

                Database.replaceLineString(Database.getTopFiveRatingsPath(), String.valueOf(rate3), 3);
                Database.replaceLineString(Database.getTopFiveBooksPath(), String.valueOf(top3), 3);

                Database.replaceLineString(Database.getTopFiveRatingsPath(), String.valueOf(rate4), 4);
                Database.replaceLineString(Database.getTopFiveBooksPath(), String.valueOf(top4), 4);

            }
            else if(rate6>rate4){
                Database.replaceLineString(Database.getTopFiveRatingsPath(), String.valueOf(rate6), 3);
                Database.replaceLineString(Database.getTopFiveBooksPath(), String.valueOf(top6), 3);
                Database.replaceLineString(Database.getTopFiveRatingsPath(), String.valueOf(rate4), 4);
                Database.replaceLineString(Database.getTopFiveBooksPath(), String.valueOf(top4), 4);
            }
            else if(rate6>rate5) {
                Database.replaceLineString(Database.getTopFiveRatingsPath(), String.valueOf(rate6), 4);
                Database.replaceLineString(Database.getTopFiveBooksPath(), String.valueOf(top6), 4);
            }
            top1 = Files.readAllLines(Paths.get(Database.getTopFiveBooksPath()), Charset.defaultCharset()).get(0);
            rate1 = Double.parseDouble(Files.readAllLines(Paths.get(Database.getTopFiveRatingsPath()), Charset.defaultCharset()).get(0));

            top2 = Files.readAllLines(Paths.get(Database.getTopFiveBooksPath()), Charset.defaultCharset()).get(1);
            rate2 = Double.parseDouble(Files.readAllLines(Paths.get(Database.getTopFiveRatingsPath()), Charset.defaultCharset()).get(1));

            top3 = Files.readAllLines(Paths.get(Database.getTopFiveBooksPath()), Charset.defaultCharset()).get(2);
            rate3 = Double.parseDouble(Files.readAllLines(Paths.get(Database.getTopFiveRatingsPath()), Charset.defaultCharset()).get(2));

            top4 = Files.readAllLines(Paths.get(Database.getTopFiveBooksPath()), Charset.defaultCharset()).get(3);
            rate4 = Double.parseDouble(Files.readAllLines(Paths.get(Database.getTopFiveRatingsPath()), Charset.defaultCharset()).get(3));

            top5 = Files.readAllLines(Paths.get(Database.getTopFiveBooksPath()), Charset.defaultCharset()).get(4);
            rate5 = Double.parseDouble(Files.readAllLines(Paths.get(Database.getTopFiveRatingsPath()), Charset.defaultCharset()).get(4));
        }

        book1.setText(String.valueOf(top1));
        book2.setText(String.valueOf(top2));
        book3.setText(String.valueOf(top3));
        book4.setText(String.valueOf(top4));
        book5.setText(String.valueOf(top5));

        rating1.setText(String.valueOf(rate1));
        rating2.setText(String.valueOf(rate2));
        rating3.setText(String.valueOf(rate3));
        rating4.setText(String.valueOf(rate4));
        rating5.setText(String.valueOf(rate5));



        back.setOnAction(event -> {
            try {
                new SceneManager(anchorPane).changeScene("BookJournal");
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

    }
}
