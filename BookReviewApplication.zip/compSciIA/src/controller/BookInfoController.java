package controller;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import database.Database;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.layout.AnchorPane;
import model.SceneManager;

public class BookInfoController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private AnchorPane anchorPane;

    @FXML
    private Button backToHomeButton;

    @FXML
    private TextArea bookNameInfo;

    @FXML
    private TextArea genreInfo;

    @FXML
    private TextArea authorInfo;

    @FXML
    void initialize() {
        bookNameInfo.setText(AddBookController.bookName);
        genreInfo.setText(AddBookController.genreName);
        authorInfo.setText(AddBookController.authorName);

        backToHomeButton.setOnAction(event -> {
            try {
                new SceneManager(anchorPane).changeScene("BookJournal");
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        }
    }

