package controller;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.ResourceBundle;

import database.Database;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.AnchorPane;
import model.AlertBox;
import model.Email;
import model.SceneManager;

public class   StudentInfoController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private AnchorPane anchorPane;

    @FXML
    private TextArea nameField;

    @FXML
    private Label booksReadCount;

    @FXML
    private Label currentBook;

    @FXML
    private Label currentGenre;

    @FXML
    private Button genreButton;

    @FXML
    private Button complexButton;

    @FXML
    private Button backToSearch;

    public static int pos2;
    private String bookTally;
    private String bookrecommend;

    String currentBookText;

    String currentGenreText;

    @FXML
    void initialize() throws FileNotFoundException {
        int index = 0;
        ArrayList<String> usernames = Database.getUsernames();
        //An ArrayList of usernames is created from the database containing all the usernames
        for (String user : usernames) {
            //A loop runs for every username
            if (SignUpController.user.equals(user)) {
                //If the input of the username in the sign up screen is the same as the one in the database
                pos2 = index;
                //the index position is saved
                break;
            }
            index++;
        }
        nameField.setText(Database.getNames().get(pos2 + 1));

        if (LogInController.pos > -1) {
            nameField.setText(Database.getNames().get(LogInController.pos));
        }
        try {
            currentBookText = Files.readAllLines(Paths.get(Database.getCurrentBookPath()), Charset.defaultCharset()).get(LogInController.pos);
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            currentGenreText = Files.readAllLines(Paths.get(Database.getGenresPath()), Charset.defaultCharset()).get(LogInController.pos);
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            //bookTally = Files.readAllLines(Paths.get(Database.getBooksReadPath()), Charset.defaultCharset()).size() > 0
            //       ? Files.readAllLines(Paths.get(Database.getBooksReadPath()), Charset.defaultCharset()).get(LogInController.pos)
            //       : "0";
            bookTally = Files.readAllLines(Paths.get(Database.getBooksReadPath()), Charset.defaultCharset()).get(LogInController.pos);
        } catch (IOException e) {
            e.printStackTrace();
        }
        double value = Double.parseDouble(bookTally);
        int val = (int) value;
        booksReadCount.setText(String.valueOf(val));

        currentBook.setText(String.valueOf(currentBookText));
        currentGenre.setText(String.valueOf(currentGenreText));

        backToSearch.setOnAction(event -> {
            try {
                new SceneManager(anchorPane).changeScene("StudentReview");
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        genreButton.setOnAction(event -> {
            try {
                bookrecommend = Files.readAllLines(Paths.get(Database.getGenreRecoPath()), Charset.defaultCharset()).get(0);
            } catch (IOException e) {
                e.printStackTrace();
            }
            new Email("khann18401@gapps.uwcsea.edu.sg", currentGenreText+" Book Recommendations", bookrecommend);
            AlertBox.display("Success", "You have successfully recommended a book!");
        });

        complexButton.setOnAction(event -> {
            try {
                bookrecommend = Files.readAllLines(Paths.get(Database.getGenreRecoPath()), Charset.defaultCharset()).get(1);
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (value>4){
                new Email("khann18401@gapps.uwcsea.edu.sg", "Complex Book Recommendations", bookrecommend);
                AlertBox.display("Success", "You have successfully recommended a book!");
            }
            else {
                new Email("khann18401@gapps.uwcsea.edu.sg", "Insufficient reading", "You are current reading an insufficient amount!" + "\n" + "Here are some book recommendations:" + "\n" + bookrecommend);
                AlertBox.display("Success", "You have successfully recommended a book!");
            }

        });

    }
}