package controller;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.FieldPosition;
import java.text.NumberFormat;
import java.text.ParsePosition;
import java.util.ArrayList;
import java.util.ResourceBundle;

import database.Database;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Slider;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import model.AlertBox;
import model.BookTally;
import model.Email;
import model.SceneManager;

public class FinishedBookSummaryController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private AnchorPane anchorPane;

    @FXML
    private TextArea bookDoneName;

    @FXML
    private Slider rating;

    @FXML
    private TextArea ratingValue;

    @FXML
    private Button backToBook;

    @FXML
    private Button doneToBook;

    @FXML
    private TextArea feedbackSender;

    public static int currentIndex;
    String bookName;
    private static final double initialValue = 0;
    String currentBook;
    public static double bookRating;


    @FXML
    void initialize() throws FileNotFoundException {
        ArrayList<String> Books = Database.getBooks();
        int ind = 0;

        try {
            currentBook = Files.readAllLines(Paths.get(Database.getCurrentBookPath()), Charset.defaultCharset()).get(LogInController.pos);
        } catch (IOException e) {
            e.printStackTrace();
        }
        bookDoneName.setText(currentBook);
        rating.setValue(initialValue);
        ratingValue.setText(String.valueOf(initialValue));
        ratingValue.textProperty().bindBidirectional(rating.valueProperty(), NumberFormat.getNumberInstance());

        for (String book : Books) {
            if (bookDoneName.getText().equals(book)) {
                currentIndex = ind;
                TopBooksController.locate = currentIndex;
                break;
            }
            ind++;
        }
        backToBook.setOnAction(event -> {
            try {
                new SceneManager(anchorPane).changeScene("BookJournal");
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        doneToBook.setOnAction(event -> {
            bookRating = Double.parseDouble(ratingValue.getText());
            AddBookController.num = 0;
            String sentFeedback = feedbackSender.getText();
            //new Email("sachinkhanna1000@gmail.com", "Book Feedback", sentFeedback);
            AlertBox.display("Success", "You have successfully rated a book! We are keen on reading your feedback!");
            try {
                BookTally.incrementBookTally();
                BookTally.incrementTotalTally();
                //BookTally.incrementTotalRating();
                //BookTally.incrementBookAverage();
                Database.replaceLineString(Database.getBookHistoryPath(), Database.getBookHistory().get(LogInController.pos) + "[" + Database.getCurrentBook().get(LogInController.pos) + "], ", LogInController.pos);
                Database.replaceLineString(Database.getCurrentAuthorPath(), "-", LogInController.pos);
                Database.replaceLineString(Database.getCurrentBookPath(), "-", LogInController.pos);
                Database.replaceLineString(Database.getCurrentPagesPath(), "0", LogInController.pos);
                Database.replaceLineString(Database.getCurrentNotesPath(), "-", LogInController.pos);
                new SceneManager(anchorPane).changeScene("BookJournal");
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

}
