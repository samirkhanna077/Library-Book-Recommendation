package controller;

import java.io.IOException;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.ResourceBundle;

import database.Database;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.layout.AnchorPane;
import model.AlertBox;
import model.BookTally;
import model.SceneManager;

public class CurrentBookReviewController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private AnchorPane anchorPane;

    @FXML
    private Button bookFinished;

    @FXML
    private Button backToHome;

    @FXML
    private TextArea pageNumber;

    @FXML
    private TextArea bookCurrent;

    @FXML
    private TextArea authorCurrent;

    @FXML
    private TextArea notes;

    @FXML
    private Button setPage;

    @FXML
    private Button setNote;

    String currentBook;

    String currentAuthor;

    String pages;

    String note;

    @FXML
    void initialize() throws IOException {

        try {
            currentBook = Files.readAllLines(Paths.get(Database.getCurrentBookPath()), Charset.defaultCharset()).get(LogInController.pos);
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            currentAuthor = Files.readAllLines(Paths.get(Database.getCurrentAuthorPath()), Charset.defaultCharset()).get(LogInController.pos);
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            pages = Files.readAllLines(Paths.get(Database.getCurrentPagesPath()), Charset.defaultCharset()).get(LogInController.pos);
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            note = Files.readAllLines(Paths.get(Database.getCurrentNotesPath()), Charset.defaultCharset()).get(LogInController.pos);
        } catch (IOException e) {
            e.printStackTrace();
        }

        bookCurrent.setText(String.valueOf(currentBook));
        authorCurrent.setText(String.valueOf(currentAuthor));
        pageNumber.setText(String.valueOf(pages));
        notes.setText(String.valueOf(note));

        setPage.setOnAction(event -> {
            try {
                Database.replaceLineString(Database.getCurrentPagesPath(), pageNumber.getText(), LogInController.pos);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        setNote.setOnAction(event -> {
            try {
                Database.replaceLineString(Database.getCurrentNotesPath(), Arrays.toString(notes.getText().split(System.lineSeparator())), LogInController.pos);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        backToHome.setOnAction(event -> {
            try {
                new SceneManager(anchorPane).changeScene("BookJournal");
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        bookFinished.setOnAction(event -> {
        //If the user presses the bookFinished button
            if (!(currentAuthor.equals("-"))){
            //If the author is not null
                try {
                    new SceneManager(anchorPane).changeScene("FinishedBookSummary");
                    //The screen will change to the FinishedBookSummary screen.
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            else {
                AlertBox.display("Error", "No Book Found");
                //An error will stop it from changing screen, and instead a message should pop up.
            }
        });

    }
}