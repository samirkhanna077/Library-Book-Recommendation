package controller;

import animation.Shaker;
import database.Database;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import model.AlertBox;
import model.SceneManager;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class TeacherLoginController {

    private boolean found;
    public static int pos=-1;

    @FXML
    private AnchorPane anchorPane;

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField teacherUsername;

    @FXML
    private PasswordField teacherPassword;

    @FXML
    private Button teacherLogInButton;

    @FXML
    private Button backToLogIn;

    @FXML
    void initialize() {
        teacherLogInButton.setOnAction(event -> {
            try {
                int index = 0;
                ArrayList<String> teacherUsernames = Database.getTeacherUsername();
                ArrayList<String> teacherPasswords = Database.getTeacherPassword();
                for (String teacherUser : teacherUsernames) {
                    if (teacherUsername.getText().equals(teacherUser)) {
                        found = true;
                        pos=index;
                        break;
                    }
                    index++;
                }
                if (!found) {
                    AlertBox.display("Error", "Teacher's username doesn't exist");
                    Shaker shaker = new Shaker(teacherUsername);
                    //instantiation of shaker object
                    shaker.shake();
                    teacherUsername.setText("");
                    teacherUsername.positionCaret(0);
                    teacherPassword.setText("");
                    teacherPassword.positionCaret(0);
                } else {
                    if (teacherPassword.getText().equals(teacherPasswords.get(index))) {
                        //Does password equal to password saved in the database of the corresponding username?
                            new SceneManager(anchorPane).changeScene("TeacherJournal");
                        //Account will login to main page
                    } else {
                        Shaker shaker = new Shaker(teacherPassword);
                        shaker.shake();
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        backToLogIn.setOnAction(event -> {
            try {
                new SceneManager(anchorPane).changeScene("LogIn");
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

    }

}
