package controller;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.ResourceBundle;

import animation.Shaker;
import database.Database;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import model.AlertBox;
import model.BookTally;
import model.Email;
import model.SceneManager;

import javax.xml.soap.Text;

public class AddBookController {

    private boolean found;
    @FXML
    private ResourceBundle resources;

    @FXML
    private Label searchText;

    @FXML
    private URL location;

    @FXML
    private TextField bookSearch;

    @FXML
    private TextField bookRecommend;

    @FXML
    private Button go;

    @FXML
    private Button sendButton;

    @FXML
    private Button thrillerButton;

    @FXML
    private Button romanceButton;

    @FXML
    private Button backToJournal;

    @FXML
    private Button nonFictionButton;

    @FXML
    private AnchorPane anchorPane;

    @FXML
    private Label genreText;

    @FXML
    private Button crimeButton;

    @FXML
    private Button recommendButton;

    @FXML
    private Button adventureButton;

    @FXML
    private Button comicButton;

    @FXML
    private Button fantasyButton;

    @FXML
    private Button fictionButton;

    @FXML
    private Button historicalButton;

    @FXML
    private Button horrerButton;

    @FXML
    private Button mysteryButton;

    @FXML
    private Button scienceButton;

    @FXML
    private Button otherButton;

    public static String bookName;

    public static String genreName;

    public static String authorName;

    public static int num = 0;

    int j = 15;

    public static String currentBook;

    @FXML
    void initialize() {
        backToJournal.setOnAction(event -> {
                    try {
                        new SceneManager(anchorPane).changeScene("BookJournal");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
        );

        recommendButton.setOnAction(event -> {
            bookRecommend.setVisible(true);
            sendButton.setVisible(true);
        }
        );
        sendButton.setOnAction(event -> {
                    String missingBook = bookRecommend.getText();
                    new Email("sachinkhanna1000@gmail.com", "Book Recommendation", missingBook);
                    AlertBox.display("Success", "You have successfully recommended a book, we will add it as soon as possible!");
                    bookRecommend.setVisible(false);
                    sendButton.setVisible(false);
                }
        );

        go.setOnAction(event -> {
                    try {
                        int index = 0;
                        ArrayList<String> Books = Database.getBooks();
                        ArrayList<String> Authors = Database.getAuthors();
                        ArrayList<String> Genres = Database.getGenres();
                        for (String book : Books) {
                            if (bookSearch.getText().equals(book)) {
                                found = true;
                                bookName = book;
                                authorName = Authors.get(index);
                                break;
                            }
                            index++;
                        }
                        if (!found) {
                            AlertBox.display("Error", "Book doesn't exist");
                            Shaker shaker = new Shaker(bookSearch);
                            shaker.shake();
                            bookSearch.setText("");
                            bookSearch.positionCaret(0);
                        } else {
                            AlertBox.display("Success", "You have successfully added a book");
                            Database.replaceLineString(Database.getCurrentBookPath(), bookSearch.getText(), LogInController.pos);
                            Database.replaceLineString(Database.getCurrentAuthorPath(), authorName, LogInController.pos);
                            genreText.setVisible(true);
                            thrillerButton.setVisible(true);
                            nonFictionButton.setVisible(true);
                            romanceButton.setVisible(true);
                            mysteryButton.setVisible(true);
                            fantasyButton.setVisible(true);
                            otherButton.setVisible(true);
                            comicButton.setVisible(true);
                            scienceButton.setVisible(true);
                            horrerButton.setVisible(true);
                            historicalButton.setVisible(true);
                            adventureButton.setVisible(true);
                            crimeButton.setVisible(true);
                            fictionButton.setVisible(true);
                            go.setVisible(false);
                            searchText.setVisible(false);
                            bookSearch.setVisible(false);
                            num = 1;


                            //System.exit(1);
                        }
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
        );

        thrillerButton.setOnAction(event -> {
                    try {
                        genreName = "Thriller";
                        new SceneManager(anchorPane).changeScene("BookInfo");
                    } catch (IOException e) {
                        e.printStackTrace();

                    }
                    j = 1;
                }
        );

        romanceButton.setOnAction(event -> {
                    try {
                        genreName = "Romance";
                        new SceneManager(anchorPane).changeScene("BookInfo");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    j = 2;
                }
        );

        nonFictionButton.setOnAction(event -> {
                    try {
                        genreName = "Non-Fiction";
                        new SceneManager(anchorPane).changeScene("BookInfo");
                        Database.replaceLineString(Database.getGenresPath(), genreName, LogInController.pos);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
        );
        crimeButton.setOnAction(event -> {
                    try {
                        genreName = "Crime";
                        new SceneManager(anchorPane).changeScene("BookInfo");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
        );
        adventureButton.setOnAction(event -> {
                    try {
                        genreName = "Adventure";
                        new SceneManager(anchorPane).changeScene("BookInfo");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
        );
        fantasyButton.setOnAction(event -> {
                    try {
                        genreName = "Fantasy";
                        new SceneManager(anchorPane).changeScene("BookInfo");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
        );
        comicButton.setOnAction(event -> {
                    try {
                        genreName = "Comic";
                        new SceneManager(anchorPane).changeScene("BookInfo");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
        );
        fictionButton.setOnAction(event -> {
                    try {
                        genreName = "Fiction";
                        new SceneManager(anchorPane).changeScene("BookInfo");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
        );
        historicalButton.setOnAction(event -> {
                    try {
                        genreName = "Historical";
                        new SceneManager(anchorPane).changeScene("BookInfo");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
        );
        horrerButton.setOnAction(event -> {
                    try {
                        genreName = "Horrer";
                        new SceneManager(anchorPane).changeScene("BookInfo");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
        );
        mysteryButton.setOnAction(event -> {
                    try {
                        genreName = "Mystery";
                        new SceneManager(anchorPane).changeScene("BookInfo");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
        );
        scienceButton.setOnAction(event -> {
                    try {
                        genreName = "Science";
                        new SceneManager(anchorPane).changeScene("BookInfo");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
        );
        otherButton.setOnAction(event -> {
                    try {
                        genreName = "Other";
                        new SceneManager(anchorPane).changeScene("BookInfo");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
        );
    }
}
