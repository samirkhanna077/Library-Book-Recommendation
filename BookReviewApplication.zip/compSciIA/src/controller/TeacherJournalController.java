package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import model.SceneManager;

public class TeacherJournalController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private AnchorPane anchorPane;

    @FXML
    private Label searchText;

    @FXML
    private Button class1;

    @FXML
    private Label searchText1;

    @FXML
    private Button class2;

    @FXML
    private Button class3;

    @FXML
    private Button class5;

    @FXML
    private Button class4;

    @FXML
    private Button class6;

    @FXML
    private Button logOut;

    @FXML
    void initialize() {
        class1.setOnAction(event -> {
            try {
                new SceneManager(anchorPane).changeScene("StudentReview");
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        logOut.setOnAction(event -> {
            try {
                new SceneManager(anchorPane).changeScene("LogIn");
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }
}