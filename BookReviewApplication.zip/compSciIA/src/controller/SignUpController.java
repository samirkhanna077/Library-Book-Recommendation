package controller;

import database.Database;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import model.AlertBox;
import model.SceneManager;

public class SignUpController {

    private boolean found = false;
    public static String user = "";

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button toLogInPage;

    @FXML
    private Label nameLabel;

    @FXML
    private TextArea success;

    @FXML
    private AnchorPane anchorPane;

    @FXML
    private TextField username;

    @FXML
    private PasswordField password;

    @FXML
    private TextField name;

    @FXML
    private Button signUpButton;

    @FXML
    private Button go;

    @FXML
    private Label usernameLabel;

    @FXML
    private Label passwordLabel;



    @FXML
    void initialize() {

        signUpButton.setOnAction(event -> {
            try {
                ArrayList<String> usernames = Database.getUsernames();
                for (String user : usernames) {
                    if (username.getText().equals(user)) {
                        AlertBox.display("Error", "This username already exists");
                        username.setText("");
                        username.positionCaret(0);
                        password.setText("");
                        password.positionCaret(0);
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    Database.addUsername(username.getText());
                    Database.addPassword(password.getText());
                    Database.addNames(name.getText());
                    user=username.getText();
                    nameLabel.setVisible(false);
                    usernameLabel.setVisible(false);
                    passwordLabel.setVisible(false);
                    name.setVisible(false);
                    username.setVisible(false);
                    password.setVisible(false);
                    name.setDisable(true);
                    username.setDisable(true);
                    password.setDisable(true);
                    signUpButton.setDisable(true);
                    signUpButton.setVisible(false);
                    toLogInPage.setVisible(false);
                    toLogInPage.setDisable(true);
                    success.setDisable(false);
                    success.setVisible(true);
                    go.setVisible(true);
                    go.setDisable(false);
                    //new SceneManager(anchorPane).activate("Book Journal");
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        toLogInPage.setOnAction(event -> {
            try {
                new SceneManager(anchorPane).changeScene("LogIn");
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        go.setOnAction(event -> {
            try {
                new SceneManager(anchorPane).changeScene("BookJournal");
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

}
